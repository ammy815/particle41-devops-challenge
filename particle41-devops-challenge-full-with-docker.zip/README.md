
# Particle41 DevOps Challenge

## Overview
This project demonstrates a minimal DevOps challenge involving a microservice and infrastructure deployment using Docker, Terraform, and AWS.

## Instructions
1. Clone the repository.
2. Build the Docker image for SimpleTimeService.
3. Use Terraform to deploy infrastructure.

## Technologies Used
- Docker
- Terraform
- AWS (ECS/EKS)
- Simple Time Service (Python)

