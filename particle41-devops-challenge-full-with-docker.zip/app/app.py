
from flask import Flask, jsonify
import socket
from datetime import datetime

app = Flask(__name__)

@app.route("/")
def home():
    return jsonify({
        "timestamp": str(datetime.now()),
        "ip": socket.gethostbyname(socket.gethostname())
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
